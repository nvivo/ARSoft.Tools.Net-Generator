﻿#region Copyright and License
// Copyright 2010..11 Alexander Reinert
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//   http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
#endregion

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ARSoft.Tools.Net.Dns
{
	public class TKeyRecord : DnsRecordBase
	{
		public enum TKeyMode : ushort
		{
			ServerAssignment = 1, // RFC2930
			DiffieHellmanExchange = 2, // RFC2930
			GssNegotiation = 3, // RFC2930
			ResolverAssignment = 4, // RFC2930
			KeyDeletion = 5, // RFC2930
		}

		public TSigAlgorithm Algorithm { get; private set; }
		public DateTime Inception { get; private set; }
		public DateTime Expiration { get; private set; }
		public TKeyMode Mode { get; private set; }
		public ReturnCode Error { get; private set; }
		public byte[] Key { get; private set; }
		public byte[] OtherData { get; private set; }

		internal TKeyRecord() {}

		public TKeyRecord(string name, TSigAlgorithm algorithm, DateTime inception, DateTime expiration, TKeyMode mode, ReturnCode error, byte[] key, byte[] otherData)
			: base(name, RecordType.TKey, RecordClass.Any, 0)
		{
			Algorithm = algorithm;
			Inception = inception;
			Expiration = expiration;
			Mode = mode;
			Error = error;
			Key = key ?? new byte[] { };
			OtherData = otherData ?? new byte[] { };
		}

		internal override void ParseRecordData(byte[] resultData, int startPosition, int length)
		{
			Algorithm = TSigAlgorithmHelper.GetAlgorithmByName(DnsMessageBase.ParseDomainName(resultData, ref startPosition));
			Inception = ParseDateTime(resultData, ref startPosition);
			Expiration = ParseDateTime(resultData, ref startPosition);
			Mode = (TKeyMode) DnsMessageBase.ParseUShort(resultData, ref startPosition);
			Error = (ReturnCode) DnsMessageBase.ParseUShort(resultData, ref startPosition);
			int keyLength = DnsMessageBase.ParseUShort(resultData, ref startPosition);
			Key = DnsMessageBase.ParseByteData(resultData, ref startPosition, keyLength);
			int otherDataLength = DnsMessageBase.ParseUShort(resultData, ref startPosition);
			OtherData = DnsMessageBase.ParseByteData(resultData, ref startPosition, otherDataLength);
		}

		internal override string RecordDataToString()
		{
			return TSigAlgorithmHelper.GetDomainName(Algorithm)
			       + " " + (int) (Inception - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds
			       + " " + (int) (Expiration - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds
			       + " " + (ushort) Mode
			       + " " + (ushort) Error
			       + " " + Key.ToBase64String()
			       + " " + OtherData.ToBase64String();
		}

		protected internal override int MaximumRecordDataLength
		{
			get { return 18 + TSigAlgorithmHelper.GetDomainName(Algorithm).Length + Key.Length + OtherData.Length; }
		}

		protected internal override void EncodeRecordData(byte[] messageData, int offset, ref int currentPosition, Dictionary<string, ushort> domainNames)
		{
			DnsMessageBase.EncodeDomainName(messageData, offset, ref currentPosition, TSigAlgorithmHelper.GetDomainName(Algorithm), false, domainNames);
			EncodeDateTime(messageData, ref currentPosition, Inception);
			EncodeDateTime(messageData, ref currentPosition, Expiration);
			DnsMessageBase.EncodeUShort(messageData, ref currentPosition, (ushort) Mode);
			DnsMessageBase.EncodeUShort(messageData, ref currentPosition, (ushort) Error);
			DnsMessageBase.EncodeUShort(messageData, ref currentPosition, (ushort) Key.Length);
			DnsMessageBase.EncodeByteArray(messageData, ref currentPosition, Key);
			DnsMessageBase.EncodeUShort(messageData, ref currentPosition, (ushort) OtherData.Length);
			DnsMessageBase.EncodeByteArray(messageData, ref currentPosition, OtherData);
		}

		internal static void EncodeDateTime(byte[] buffer, ref int currentPosition, DateTime value)
		{
			int timeStamp = (int) (value.ToUniversalTime() - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalSeconds;
			DnsMessageBase.EncodeInt(buffer, ref currentPosition, timeStamp);
		}

		private static DateTime ParseDateTime(byte[] buffer, ref int currentPosition)
		{
			int timeStamp = DnsMessageBase.ParseInt(buffer, ref currentPosition);
			return new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc).AddSeconds(timeStamp).ToLocalTime();
		}
	}
}